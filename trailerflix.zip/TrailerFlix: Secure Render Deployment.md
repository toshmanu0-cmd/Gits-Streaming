# TrailerFlix: Secure Render Deployment

This version keeps the TMDB API key on the server. The browser calls local `/api/...` routes, while `server.js` reads `process.env.TMDB_API_KEY` and adds the key only when contacting TMDB.

## Files

| File | Purpose |
|---|---|
| `index.html` | TrailerFlix page structure |
| `style.css` | Page styling |
| `app.js` | Browser UI and calls to the local API proxy |
| `server.js` | Express server, TMDB proxy, and static-file server |
| `package.json` | Node.js dependency and start command |
| `.env.example` | Safe template showing the required variable name |
| `.gitignore` | Prevents `.env` and dependencies from being committed |

## Deploy on Render

1. Create a GitHub repository and upload these project files. Do **not** upload a real `.env` file or put the TMDB key in `app.js`, `index.html`, or `render.yaml`.
2. In the [Render Dashboard](https://dashboard.render.com), choose **New → Web Service**, connect the repository, and select the branch to deploy.
3. Use these settings:

   | Render setting | Value |
   |---|---|
   | Language | `Node` |
   | Build Command | `npm install` |
   | Start Command | `npm start` |

4. In the service’s **Environment** page, add this environment variable:

   | Key | Value |
   |---|---|
   | `TMDB_API_KEY` | Your TMDB API key |

   Save and deploy the service. Render makes environment variables available to the running service without placing them in the source repository [1].
5. Open the generated `onrender.com` URL after the deploy finishes. Render requires web services to listen on the `PORT` environment variable and bind to `0.0.0.0`; `server.js` does both [2].

## Local testing

For local testing, create a file named `.env` containing:

```bash
TMDB_API_KEY=your_real_key_here
```

Do not commit that file. The current server reads environment variables directly, so start it from a terminal with:

```bash
TMDB_API_KEY=your_real_key_here npm start
```

Then visit `http://localhost:10000`. On Windows PowerShell, use:

```powershell
$env:TMDB_API_KEY="your_real_key_here"; npm start
```

## Security notes

The key must never appear in browser code. A key placed in `app.js` is visible to every visitor through browser developer tools, even if the repository is private. If a key has already been exposed, revoke or regenerate it in the TMDB account before deploying this version.

The proxy currently exposes only the operations needed by the page: movie search, weekly trending movies, genre discovery, and movie videos. It does not expose the TMDB key in its JSON responses.

## References

[1]: https://render.com/docs/configure-environment-variables "Render: Environment Variables and Secrets"

[2]: https://render.com/docs/web-services "Render: Web Services"
